'use client';

import { cn } from '@/lib/utils';
import { ScrollReveal } from '@/components/scroll-reveal';

interface SectionHeadingProps {
  eyebrow: string;
  title: string;
  description?: string;
  className?: string;
  align?: 'left' | 'center';
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  className,
  align = 'center',
}: SectionHeadingProps) {
  return (
    <div
      className={cn(
        'flex flex-col gap-4 mb-16',
        align === 'center' && 'items-center text-center',
        align === 'left' && 'items-start text-left',
        className
      )}
    >
      <ScrollReveal tilt={10} y={12}>
        <div className="flex items-center gap-2">
          <span className="h-px w-8 bg-gradient-to-r from-transparent to-blue-500" />
          <span className="text-xs font-mono uppercase tracking-[0.2em] text-blue-400">
            {eyebrow}
          </span>
          <span className="h-px w-8 bg-gradient-to-l from-transparent to-blue-500" />
        </div>
      </ScrollReveal>

      <ScrollReveal tilt={14} y={16} delay={0.05}>
        <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight text-gradient">
          {title}
        </h2>
      </ScrollReveal>

      {description && (
        <ScrollReveal tilt={10} y={16} delay={0.1}>
          <p
            className={cn(
              'text-muted-foreground text-base md:text-lg max-w-2xl leading-relaxed',
              align === 'center' && 'mx-auto'
            )}
          >
            {description}
          </p>
        </ScrollReveal>
      )}
    </div>
  );
}
