'use client';

import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import { useMemo } from 'react';

/**
 * Thin overlay layers that sit on top of the fixed background image.
 * The image itself is applied on <html> in globals.css.
 *
 * Layer 1: Glow orbs that drift at different scroll speeds (parallax depth)
 * Layer 2: Tiny floating particles
 * Layer 3: Vignette to keep edges dark and focus the center
 */
export function AnimatedBackground() {
  const prefersReducedMotion = useReducedMotion();
  const { scrollY } = useScroll();

  // Different layers move at different rates as you scroll — the classic
  // parallax trick that reads as "depth" rather than a flat page.
  const orbANearY = useTransform(scrollY, [0, 3000], [0, prefersReducedMotion ? 0 : -900]);
  const orbBFarY = useTransform(scrollY, [0, 3000], [0, prefersReducedMotion ? 0 : -350]);
  const orbCFarY = useTransform(scrollY, [0, 3000], [0, prefersReducedMotion ? 0 : -550]);
  const orbANearX = useTransform(scrollY, [0, 3000], [0, prefersReducedMotion ? 0 : 150]);
  const orbCFarX = useTransform(scrollY, [0, 3000], [0, prefersReducedMotion ? 0 : -120]);

  const particles = useMemo(
    () =>
      Array.from({ length: 16 }).map((_, i) => ({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 1.5 + 0.5,
        duration: Math.random() * 22 + 18,
        delay: Math.random() * 10,
      })),
    []
  );

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      {/* Aurora — a large, slowly rotating conic gradient blurred into soft color bands.
          This is what makes the background feel alive/premium instead of static. */}
      <motion.div
        className="absolute left-1/2 top-1/2 h-[1400px] w-[1400px] -translate-x-1/2 -translate-y-1/2 opacity-30"
        style={{
          background:
            'conic-gradient(from 0deg, #2563eb, #6366f1, #8b5cf6, #06b6d4, #2563eb)',
          filter: 'blur(160px)',
        }}
        animate={prefersReducedMotion ? undefined : { rotate: 360 }}
        transition={{ duration: 90, repeat: Infinity, ease: 'linear' }}
      />

      {/* Fine grain texture — procedural SVG noise, stays crisp at any resolution */}
      <svg className="absolute inset-0 h-full w-full opacity-[0.035] mix-blend-overlay">
        <filter id="grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" />
      </svg>

      {/* Perspective grid — floor-like plane receding into the distance, faded at the edges
          via a mask so it reads as an infinite floor rather than a tiled pattern. */}
      <div
        className="absolute inset-0 opacity-[0.09]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(120,160,255,0.7) 1px, transparent 1px), linear-gradient(90deg, rgba(120,160,255,0.7) 1px, transparent 1px)',
          backgroundSize: '64px 64px',
          transform: 'perspective(500px) rotateX(60deg) scale(2)',
          transformOrigin: 'center top',
          maskImage: 'radial-gradient(ellipse 70% 60% at 50% 20%, black 40%, transparent 90%)',
          WebkitMaskImage:
            'radial-gradient(ellipse 70% 60% at 50% 20%, black 40%, transparent 90%)',
        }}
      />

      {/* Parallax glow orbs — nearest moves fastest, farthest moves slowest.
          Each also drifts continuously so the scene feels alive even before you scroll. */}
      <motion.div
        style={{ y: orbANearY, x: orbANearX }}
        animate={prefersReducedMotion ? undefined : { scale: [1, 1.15, 1] }}
        transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute -top-40 left-[5%] h-[560px] w-[560px] rounded-full bg-blue-500/20 blur-[130px]"
      />
      <motion.div
        style={{ y: orbCFarY, x: orbCFarX }}
        animate={prefersReducedMotion ? undefined : { scale: [1, 1.2, 1] }}
        transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
        className="absolute top-[35%] -right-10 h-[520px] w-[520px] rounded-full bg-indigo-500/20 blur-[140px]"
      />
      <motion.div
        style={{ y: orbBFarY }}
        animate={prefersReducedMotion ? undefined : { scale: [1, 1.1, 1] }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
        className="absolute top-[80%] left-[15%] h-[460px] w-[460px] rounded-full bg-purple-500/16 blur-[120px]"
      />
      <motion.div
        animate={prefersReducedMotion ? undefined : { scale: [1, 1.25, 1], opacity: [0.5, 0.8, 0.5] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
        className="absolute top-[15%] right-[25%] h-[300px] w-[300px] rounded-full bg-cyan-400/14 blur-[100px]"
      />

      {/* Tiny floating particles */}
      {!prefersReducedMotion &&
        particles.map((p) => (
          <motion.div
            key={p.id}
            className="absolute rounded-full bg-white"
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              width: Math.min(p.size, 2),
              height: Math.min(p.size, 2),
            }}
            animate={{
              y: [0, -35, 0],
              opacity: [0, 0.5, 0],
            }}
            transition={{
              duration: p.duration,
              delay: p.delay,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
        ))}

      {/* Vignette — darkens edges, focuses center */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse 100% 100% at 50% 50%, transparent 40%, rgba(0,0,0,0.4) 100%)',
        }}
      />
    </div>
  );
}
