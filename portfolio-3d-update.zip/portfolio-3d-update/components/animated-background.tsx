'use client';

import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import { useMemo } from 'react';

/**
 * Thin overlay layers that sit on top of the fixed background image.
 * The image itself is applied on <html> in globals.css.
 *
 * Layer 1: Glow orbs that drift at different scroll speeds (parallax depth)
 * Layer 2: Tiny floating particles
 * Layer 3: Vignette to keep edges dark and focus the center
 */
export function AnimatedBackground() {
  const prefersReducedMotion = useReducedMotion();
  const { scrollY } = useScroll();

  // Different layers move at different rates as you scroll — the classic
  // parallax trick that reads as "depth" rather than a flat page.
  const orbANearY = useTransform(scrollY, [0, 3000], [0, prefersReducedMotion ? 0 : -600]);
  const orbBFarY = useTransform(scrollY, [0, 3000], [0, prefersReducedMotion ? 0 : -220]);
  const orbCFarY = useTransform(scrollY, [0, 3000], [0, prefersReducedMotion ? 0 : -320]);

  const particles = useMemo(
    () =>
      Array.from({ length: 16 }).map((_, i) => ({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 1.5 + 0.5,
        duration: Math.random() * 22 + 18,
        delay: Math.random() * 10,
      })),
    []
  );

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      {/* Parallax glow orbs — nearest moves fastest, farthest moves slowest */}
      <motion.div
        style={{ y: orbANearY }}
        className="absolute -top-40 left-[10%] h-[420px] w-[420px] rounded-full bg-blue-500/10 blur-[110px]"
      />
      <motion.div
        style={{ y: orbCFarY }}
        className="absolute top-[40%] right-[5%] h-[380px] w-[380px] rounded-full bg-indigo-500/10 blur-[120px]"
      />
      <motion.div
        style={{ y: orbBFarY }}
        className="absolute top-[85%] left-[20%] h-[320px] w-[320px] rounded-full bg-purple-500/8 blur-[100px]"
      />

      {/* Tiny floating particles */}
      {!prefersReducedMotion &&
        particles.map((p) => (
          <motion.div
            key={p.id}
            className="absolute rounded-full bg-white"
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              width: Math.min(p.size, 2),
              height: Math.min(p.size, 2),
            }}
            animate={{
              y: [0, -35, 0],
              opacity: [0, 0.012, 0],
            }}
            transition={{
              duration: p.duration,
              delay: p.delay,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
        ))}

      {/* Vignette — darkens edges, focuses center */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse 100% 100% at 50% 50%, transparent 45%, rgba(0,0,0,0.45) 100%)',
        }}
      />
    </div>
  );
}
