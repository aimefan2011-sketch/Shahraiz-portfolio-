'use client';

import {
  motion,
  useMotionValue,
  useSpring,
  useTransform,
  useReducedMotion,
} from 'framer-motion';
import { type MouseEvent, type ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface TiltCardProps {
  children: ReactNode;
  className?: string;
  /** Max tilt in degrees when the cursor is at the card's edge. */
  maxTilt?: number;
  /** Pixels of "lift" toward the viewer on hover. */
  lift?: number;
  glare?: boolean;
}

/**
 * Wraps content in a card that tilts in 3D toward the cursor, with a
 * soft light "glare" that tracks the pointer — the classic professional
 * SaaS-site card effect (Stripe/Linear style), built on top of the
 * physical scroll-in tilt from ScrollReveal.
 */
export function TiltCard({
  children,
  className,
  maxTilt = 10,
  lift = 12,
  glare = true,
}: TiltCardProps) {
  const prefersReducedMotion = useReducedMotion();

  const mouseX = useMotionValue(0.5);
  const mouseY = useMotionValue(0.5);

  const springConfig = { stiffness: 220, damping: 20, mass: 0.6 };
  const springX = useSpring(mouseX, springConfig);
  const springY = useSpring(mouseY, springConfig);

  const rotateX = useTransform(springY, [0, 1], [maxTilt, -maxTilt]);
  const rotateY = useTransform(springX, [0, 1], [-maxTilt, maxTilt]);
  const translateZ = useSpring(0, springConfig);

  const glareX = useTransform(springX, [0, 1], ['0%', '100%']);
  const glareY = useTransform(springY, [0, 1], ['0%', '100%']);

  function handleMouseMove(e: MouseEvent<HTMLDivElement>) {
    if (prefersReducedMotion) return;
    const rect = e.currentTarget.getBoundingClientRect();
    mouseX.set((e.clientX - rect.left) / rect.width);
    mouseY.set((e.clientY - rect.top) / rect.height);
    translateZ.set(lift);
  }

  function handleMouseLeave() {
    mouseX.set(0.5);
    mouseY.set(0.5);
    translateZ.set(0);
  }

  return (
    <motion.div
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateX: prefersReducedMotion ? 0 : rotateX,
        rotateY: prefersReducedMotion ? 0 : rotateY,
        translateZ: prefersReducedMotion ? 0 : translateZ,
        transformPerspective: 1000,
        transformStyle: 'preserve-3d',
      }}
      className={cn('relative', className)}
    >
      {children}

      {glare && !prefersReducedMotion && (
        <motion.div
          aria-hidden
          className="pointer-events-none absolute inset-0 rounded-[inherit] opacity-0 hover:opacity-100 transition-opacity duration-300"
          style={{
            background: useTransform(
              [glareX, glareY],
              ([gx, gy]) =>
                `radial-gradient(circle at ${gx} ${gy}, rgba(255,255,255,0.12), transparent 60%)`
            ),
          }}
        />
      )}
    </motion.div>
  );
}
