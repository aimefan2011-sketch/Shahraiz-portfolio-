'use client';

import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import { useRef, type ReactNode } from 'react';

interface ScrollRevealProps {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
  /** Max tilt in degrees. Set to 0 to disable the 3D rotation. */
  tilt?: number;
}

export function ScrollReveal({
  children,
  delay = 0,
  y = 24,
  className,
  tilt = 16,
}: ScrollRevealProps) {
  const prefersReducedMotion = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);

  // Track this element's own position as it enters/leaves the viewport,
  // so the tilt/scale/fade are driven directly by scroll, not just a one-shot animation.
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start 92%', 'start 40%'],
  });

  const effectiveTilt = prefersReducedMotion ? 0 : tilt;

  const rotateX = useTransform(scrollYProgress, [0, 1], [effectiveTilt, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [effectiveTilt ? 0.92 : 1, 1]);
  const opacity = useTransform(scrollYProgress, [0, 1], [0, 1]);
  const translateY = useTransform(
    scrollYProgress,
    [0, 1],
    [prefersReducedMotion ? 0 : y, 0]
  );

  return (
    <motion.div
      ref={ref}
      className={className}
      style={{
        rotateX,
        scale,
        opacity,
        y: translateY,
        transformPerspective: 1200,
        transformStyle: 'preserve-3d',
      }}
      transition={{ delay }}
    >
      {children}
    </motion.div>
  );
}
